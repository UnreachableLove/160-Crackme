﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>


int Key()
{
	unsigned long serial = 0xF6EEDB88;
	char szName[20] = { 0 };
	unsigned long* p;

	printf("请输入用户名:");
	scanf_s("%s", szName, 20);

	for (int i = 15; i >= 0; i--)
	{
		p = (unsigned long*)& szName[i];
		serial ^= *p;
		serial--;
	}

	printf("%u", serial);
	return 0;
}

int main(int argc, char* argv[])
{
	Key();
	return 0;
}