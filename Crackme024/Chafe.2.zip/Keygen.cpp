﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>

int Keygen()
{
	unsigned long key = 0x58455443;
	char szName[20] = { 0 };
	unsigned long* p;

	printf("请输入用户名:");
	scanf_s("%s", szName, 20);

	for (int i = 0; i <= 15; i++)
	{
		p = (unsigned long*)& szName[i];
		key += *p;
		
	}
	unsigned long serial = 0x580C3BA3 - key;
	printf("%u", serial);

	return 0;
}

int main(int argc, char* argv[])
{
	Keygen();
	return 0;
}