﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>


int Keygen()
{
	char szName[20] = { 0 };
	char szSerial[100] = { 0 };
	char szSerial1[20] = { 0 };
	int NameLen = 0;
	__int64 Result = 0;
	__int64 Result1 = 0;


	printf("请输入用户名:");
	scanf_s("%s", szName, 20);
	NameLen = strlen(szName);

	Result = (szName[NameLen - 1] * 432.4 * 17.79) / 15;

	Result1 = szName[0] + Result;
	sprintf(szSerial1, "%I64d", Result1);
	strcat(szSerial, szSerial1);

	Result1 = Result - szName[0] * 0x19;
	sprintf(szSerial1, "%I64X", Result1);
	strcat(szSerial, szSerial1);

	sprintf(szSerial1, "%I64X", Result);
	strcat(szSerial, szSerial1);

	Result1 = szName[0] * 0x5 - 0x1B;
	sprintf(szSerial1, "%I64d", Result1);
	strcat(szSerial, szSerial1);

	Result1 = NameLen;
	sprintf(szSerial1, "%I64d", Result1);
	strcat(szSerial, szSerial1);

	strcat(szSerial, "-CM");

	printf("%s\n", szSerial);

	return 0;
}

int main(int argc, char* argv[])
{
	Keygen();
	system("pause");
	return 0;
}