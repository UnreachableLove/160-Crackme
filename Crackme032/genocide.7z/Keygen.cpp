﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>

int Keygen()
{
	char szName[20] = { 0 };
	char szSerial[20] = { 0 };
	__int64 Result = 0;

	printf("请输入用户名:");
	scanf_s("%s", szName, 20);

	for (int i = 0x0; i < 5; i++)
	{
		if (i != 1)
		{
			Result = szName[i] / 0xA;
			if (Result > 9)
			{
				Result = Result / 0xA;
			}
			printf("%I64d", Result);
		}
	}

	return 0;
}

int main(int argc, char* argv[])
{
	Keygen();
	return 0;
}