﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>


int Keygen()
{
	char szName[20] = { 0 };
	char szSerial[20] = { 0 };
	int NameLen = 0;
	__int64 Result = 0;


	printf("请输入用户名:");
	scanf_s("%s", szName, 20);
	NameLen = strlen(szName);

	for (int i = 0x0; i < NameLen; i++)
	{
		if (szName[i] < 0x41 || szName[i] > 0x5A)
		{
			printf("错误！请输入大写字母。\n");
			return 0;
		}
		Result += szName[i];

	}
	
	Result ^= (0x5678 ^ 0x1234);
	sprintf(szSerial, "%I64d", Result);

	printf("%s\n", szSerial);

	return 0;
}

int main(int argc, char* argv[])
{
	Keygen();
	return 0;
}