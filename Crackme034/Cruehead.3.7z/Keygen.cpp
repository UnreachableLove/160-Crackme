﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>


int Keygen()
{
	char szName[20] = { 0 };
	char szSerial[20] = { 0 };
	int NameLen = 0;
	__int64 Result = 0;

	printf("请输入14字节值:");
	scanf_s("%s", szSerial, 20);
	NameLen = strlen(szSerial);
	if (NameLen != 14)
	{
		printf("不是十四字节! %d", NameLen);
		return 0;
	}

	for (int i = 0; i < 14; i++)
	{
		szSerial[i] ^= (0x41 + i);
		Result += szSerial[i];
	}
	
	Result ^= 0x12345678;

	char* serial = (char*)&Result;
	for (int i = 0; i < 4; i++)
	{
		printf("%c", serial[i]);
	}

	return 0;
}


int main(int argc, char* argv[])
{
	Keygen();
	return 0;
}