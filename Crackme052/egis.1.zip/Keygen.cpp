﻿#include <stdio.h>
#include <string.h>
#include <Windows.h>

int Keygen()
{
	unsigned long key[4] = { 0x0000C9B8, 0x37D4BC64, 0x1D98AF82, 0xDBF464AA };


	for (int i = 2; i >= 0; i--)
	{
		unsigned long num = 0xBADC0DE / (i + 0x50);
		unsigned long esi = *(key + i);
		unsigned long edi = *(key + i + 1);
		int C = 0;


		for (unsigned long j = num; j > 0; j--)
		{

			C = ((esi & 0x4) >> 2) ^ ((esi & 0x2000) >> 13) ^ ((esi & 0x80000000) >> 31);
			edi = edi ^ C;

			int DH = esi & 1;		//DH 为原来 edi 的最高位
			int AH = edi & 1;		//AH 为原来 esi 的最高位

			esi = (esi >> 1) | (AH << 31);
			edi = (edi >> 1) | (DH << 31);

		}
		*(key + i)		= esi;
		*(key + i + 1)	= edi;
	}
	printf("%X %X %X %X", key[0], key[1], key[2], key[3]);

	return 0;
}


int main(int argc, char* argv[])
{

	Keygen();
	return 0;
}